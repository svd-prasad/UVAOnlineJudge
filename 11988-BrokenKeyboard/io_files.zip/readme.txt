This package contains the gift I/O files of:

Rujia Liu's Present 3: A Data Structure Contest Celebrating the 100th Anniversary of Tsinghua University

Warning: The files are in DOS format. If you want to use them under *nix/MacOS, please be careful.

For any comments and/or bug report, please send to rujia.liu@gmail.com

Enjoy!
